/**
 * Seedance Studio — Backend Server
 * 
 * Proxies all BytePlus API calls to avoid CORS issues.
 * 
 * HOW TO RUN:
 *   1. Install Node.js (https://nodejs.org) if you don't have it
 *   2. Put this file and seedance-studio.html in the same folder
 *   3. Run:  node server.js
 *   4. Open browser at:  http://localhost:3000
 * 
 * No npm install needed — uses only built-in Node.js modules.
 */

const http  = require('http');
const https = require('https');
const fs    = require('fs');
const path  = require('path');
const url   = require('url');

const PORT       = 3000;
const BYTEPLUS   = 'ark.ap-southeast.bytepluses.com';
const API_PREFIX = '/api/v3';

// ── Serve the HTML frontend ──────────────────────────────────────────
function serveHTML(res) {
  const filePath = path.join(__dirname, 'seedance-studio.html');
  fs.readFile(filePath, (err, data) => {
    if (err) {
      res.writeHead(404); res.end('seedance-studio.html not found');
      return;
    }
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end(data);
  });
}

// ── Proxy to BytePlus ────────────────────────────────────────────────
function proxy(req, res, bodyBuffer) {
  // Strip /proxy prefix
  const target = req.url.replace(/^\/proxy/, '');

  const options = {
    hostname: BYTEPLUS,
    port: 443,
    path: target,
    method: req.method,
    headers: {}
  };

  // Forward relevant headers, drop host
  const skip = ['host', 'origin', 'referer'];
  for (const [k, v] of Object.entries(req.headers)) {
    if (!skip.includes(k.toLowerCase())) {
      options.headers[k] = v;
    }
  }

  const proxyReq = https.request(options, (proxyRes) => {
    // CORS headers so browser is happy
    res.writeHead(proxyRes.statusCode, {
      ...proxyRes.headers,
      'Access-Control-Allow-Origin':  '*',
      'Access-Control-Allow-Headers': '*',
      'Access-Control-Allow-Methods': '*',
    });
    proxyRes.pipe(res);
  });

  proxyReq.on('error', (e) => {
    console.error('Proxy error:', e.message);
    res.writeHead(502);
    res.end(JSON.stringify({ error: { message: 'Proxy error: ' + e.message } }));
  });

  if (bodyBuffer && bodyBuffer.length) proxyReq.write(bodyBuffer);
  proxyReq.end();
}

// ── Main server ──────────────────────────────────────────────────────
const server = http.createServer((req, res) => {
  // CORS preflight
  if (req.method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin':  '*',
      'Access-Control-Allow-Headers': '*',
      'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
    });
    res.end();
    return;
  }

  // Serve frontend
  if (req.url === '/' || req.url === '/index.html') {
    return serveHTML(res);
  }

  // Proxy API calls
  if (req.url.startsWith('/proxy/')) {
    const chunks = [];
    req.on('data', c => chunks.push(c));
    req.on('end', () => proxy(req, res, Buffer.concat(chunks)));
    return;
  }

  res.writeHead(404); res.end('Not found');
});

server.listen(PORT, () => {
  console.log('');
  console.log('  ╔══════════════════════════════════════╗');
  console.log('  ║   🎬  Seedance Studio is running!    ║');
  console.log('  ╠══════════════════════════════════════╣');
  console.log(`  ║   Open: http://localhost:${PORT}         ║`);
  console.log('  ║   Stop: Ctrl+C                       ║');
  console.log('  ╚══════════════════════════════════════╝');
  console.log('');
});
